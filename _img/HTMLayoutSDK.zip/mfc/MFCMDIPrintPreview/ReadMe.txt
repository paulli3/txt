Sample demonstrating HTMLayout based print preview view for MFC.
Thanks to its author: Damir Valiulin, May 2006