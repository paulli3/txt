// HTMPanel.cpp : implementation file
//

#include "stdafx.h"
#include "Wizard.h"
#include "HTMPanel.h"


// CHTMPanel

IMPLEMENT_DYNAMIC(CHTMPanel, CWnd)
CHTMPanel::CHTMPanel()
{
}

CHTMPanel::~CHTMPanel()
{
}


BEGIN_MESSAGE_MAP(CHTMPanel, CWnd)
END_MESSAGE_MAP()



// CHTMPanel message handlers

