//{{NO_DEPENDENCIES}}
// Microsoft Visual C++ generated include file.
// Used by browse.rc
//
#define IDD_ABOUTBOX                    100
#define IDR_MAINFRAME                   128
#define IDCSS_MASTER_SHEET              206
#define IDR_MASTER_CSS                  210
#define IDR_ABOUT                       234
#define IDR_INPUT_DIALOG                235
#define ID_FILE_NEW_WINDOW              32771
#define ID_TEST_FETCH_CONTROLS          32772
#define ID_GET_HTML                     32773
#define IDC_GET_DOC_TEXT                32774
#define ID_SELECTION_MODE               32775
#define ID_MIN_MAX_INFO                 32776
#define ID_UPDATE_TEST                  32777
#define ID_TEST_SCROLL_TO_BOTTOM        32778
#define ID_TEST_FIND_ELEMENTS           32779
#define ID_TEST_PROBE                   32780
#define ID_TEST_INSERT_OPTION           32781
#define ID_TEST_REMOVE_OPTION           32782
#define ID_TEST_RESET_CONTROLS          32783
#define ID_TEST_MASTER_CSS              32784
#define ID_TEST_CSS                     32785
#define ID_TEST_SELECT_TEXT             32786
#define ID_TEST_GET_SELECTED_TEXT       32787
#define ID_TEST_REPLACE_SELECTED_TEXT   32788
#define ID_TEST_SET_HTML                32789
#define ID_TEST_TABLES                  32790
#define ID_INPUT_DIALOG                 32791
#define ID_TEST_CLONE                   32792
#define ID_TEST_SET_TEXT                32793
#define ID_TEST_SET_CARET               32794
#define ID_TEST_SET_HTTP_HEADER         32795
#define ID_FILE_RELOAD                  32796
#define ID_TEST_ENUMERATE               32797
#define ID_TEST_GET_CARET_POSITION      32798
#define ID_TEST_SCROLL_TO_ELEMENT       32799
#define ID_TEST_RICHTEXT_LOAD_FILE      32800
#define ID_TEST_SCROLL_RICHTEXT         32801
#define ID_TEST_SET_ATTR                32802
#define ID_TEST_CLEAR_ATTR              32803
#define ID_FILE_VIEW_SOURCE             32804
#define ID_FILE_GOBACK                  32805
#define ID_FILE_GOFORWARD               32806
#define ID_TEST_UPDATE_WINDOW           32807
#define ID_TEST_TRACK_POPUP             32808
#define ID_TEST_CLEAR                   32809
#define ID_TEST_SHOW_POPUP              32810
#define ID_SAVE_AS_PNG                  32811
#define ID_SAVE_AS_JPEG                 32812
#define ID_TESTS_SWITCHTAB              32813
#define ID_TESTS_SETCTLVALUE            32814
#define ID_FILE_OPEN_URL                61403

// Next default values for new objects
// 
#ifdef APSTUDIO_INVOKED
#ifndef APSTUDIO_READONLY_SYMBOLS
#define _APS_NEXT_RESOURCE_VALUE        253
#define _APS_NEXT_COMMAND_VALUE         32815
#define _APS_NEXT_CONTROL_VALUE         1000
#define _APS_NEXT_SYMED_VALUE           101
#endif
#endif
