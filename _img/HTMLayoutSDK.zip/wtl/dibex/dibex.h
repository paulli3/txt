// dibex.h
