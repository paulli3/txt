PrintEx interface demo.

HTMLayout prints HTML on any DC at any position
and without any HWND.
