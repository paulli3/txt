//{{NO_DEPENDENCIES}}
// Microsoft Developer Studio generated include file.
// Used by printex.rc
//
#define IDD_ABOUTBOX                    100
#define IDR_MAINFRAME                   128
#define IDD_MAINDLG                     129
#define IDC_RADIO1                      1000
#define IDC_RADIO2                      1001
#define IDC_RADIO3                      1002
#define IDC_OPEN                        1003
#define IDC_URL                         1004
#define IDC_LOAD_URL                    1005
#define IDC_MINUS                       1007
#define IDC_PLUS                        1008
#define IDC_PRINT                       1009
#define IDC_EMF                         1010

// Next default values for new objects
// 
#ifdef APSTUDIO_INVOKED
#ifndef APSTUDIO_READONLY_SYMBOLS
#define _APS_NEXT_RESOURCE_VALUE        202
#define _APS_NEXT_COMMAND_VALUE         32772
#define _APS_NEXT_CONTROL_VALUE         1011
#define _APS_NEXT_SYMED_VALUE           101
#endif
#endif
