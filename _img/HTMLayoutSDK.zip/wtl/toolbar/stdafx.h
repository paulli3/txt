// stdafx.h : include file for standard system include files,
//  or project specific include files that are used frequently, but
//      are changed infrequently
//

#if !defined(AFX_STDAFX_H__F8AEFCCD_FACE_4662_8086_41E7B7018223__INCLUDED_)
#define AFX_STDAFX_H__F8AEFCCD_FACE_4662_8086_41E7B7018223__INCLUDED_

// Change these values to use different versions
#define _WIN32_WINNT  0x0501
#define _WIN32_IE 0x501
#define _RICHEDIT_VER 0x0100


#include <atlbase.h>
#include <atlapp.h>

extern CAppModule _Module;

#include <atlwin.h>

#include "wtl_htmlayout.h"
#include "wtl_htmlayouthost.h"
#include "wtl_htmlpopup.h"
#include "aux-cvt.h"
#include "aux-slice.h"
#include "value.h"


//{{AFX_INSERT_LOCATION}}
// Microsoft Visual C++ will insert additional declarations immediately before the previous line.

#endif // !defined(AFX_STDAFX_H__F8AEFCCD_FACE_4662_8086_41E7B7018223__INCLUDED_)
