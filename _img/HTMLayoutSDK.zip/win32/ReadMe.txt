========================================================================
       WIN32 APPLICATION : win32
========================================================================

Minimalistic HTMLayout integration sample.
Uses plain win32 API calls.