# vim-racket

Module for use in [pathogen](https://github.com/tpope/vim-pathogen).

## Thanks

Most of the real work on this module was done by [Paul Cannon](https://github.com/thepaul) and [Asumu Takikawa](https://github.com/takikawa).

To see all the contributors,

    git log | grep ^Author: | sed 's/ <.*//; s/^Author: //' | sort | uniq -c | sort -nr
