using System;

public class HelloWorld : IBob
{
    public static void Main(string[] args)
    {
        System.Console.WriteLine("Bob");
    }
}
