# Swift.vim

Syntax and indent files for [Swift](https://developer.apple.com/swift/)

If you don't have a preferred installation method check out
[vim-plug](https://github.com/junegunn/vim-plug)

## Examples

![](https://raw.githubusercontent.com/Keithbsmiley/swift.vim/master/screenshots/screen.png)
![](https://raw.githubusercontent.com/Keithbsmiley/swift.vim/master/screenshots/screen2.png)


### Development

I plan to continuing improving this plugin as I find more issues with
it. If you find anything strange with highlighting or indention *please*
[submit an issue](https://github.com/Keithbsmiley/swift.vim/issues/new).
