<?php
namespace NS1;
class Foo {
}
const ZAP = '';
function bar(){}

interface FooInterface {
}


namespace NS1\SUBNS;
class FooSub {
}
function barsub(){
print 'barsub';
}
const ZAPSUB = '';



namespace NS1\SUBNS\SUBSUB;
class FooSubSub {
}
function barsubsub(){
print 'barsubsub';
}
const ZAPSUBSUB = '';
