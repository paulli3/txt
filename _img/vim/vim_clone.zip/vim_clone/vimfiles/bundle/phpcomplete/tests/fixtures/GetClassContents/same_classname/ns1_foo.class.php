<?php

namespace NS1;

class Foo { }
