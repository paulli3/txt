<?php
namespace NS1;
use NS2\NamespacedFoo as NamespacedFoo;

class NamespacedFoo2 extends NamespacedFoo {}
