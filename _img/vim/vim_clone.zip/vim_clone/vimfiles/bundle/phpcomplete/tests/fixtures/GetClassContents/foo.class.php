<?php
class FooClass {
    public function bar( $baz = 'foo') {
    }
}
