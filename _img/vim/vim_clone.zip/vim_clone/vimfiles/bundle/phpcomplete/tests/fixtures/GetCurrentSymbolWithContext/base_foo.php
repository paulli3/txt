<?php

class BaseFoo {

	public function inherited() {

	}

}
