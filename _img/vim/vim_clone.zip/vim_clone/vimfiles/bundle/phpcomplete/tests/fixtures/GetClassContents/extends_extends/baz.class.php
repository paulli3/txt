<?php

class BazClass { }
